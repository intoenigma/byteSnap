# byteSnap

A Python utility to manage image files by creating folders and copying them.

## Installation
```bash
pip install byteSnap
